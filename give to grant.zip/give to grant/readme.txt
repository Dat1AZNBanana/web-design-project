open page.html first
